<?php

namespace phrqndy\frs\core;
use phrqndy\frs\core\listeners\PlayerListener;
use phrqndy\vexo\core\tasks\DaytimeTask;
use pocketmine\plugin\PluginBase;


class FRSMaster extends PluginBase {

    public function onEnable(): void {


        $this->getLogger()->info("FRSMaster Loaded");
        $this->LDL();

    }
    public function LDL(): void {

        $srp = $this->getServer()->getPluginManager();

        $srp->registerEvents(new PlayerListener(), $this);


    }

    public function loadTasks(): void {
        $this->getScheduler()->scheduleRepeatingTask(new \tasks\DaylightTask(), 1200);
    }
}