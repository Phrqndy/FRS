<?php

namespace phrqndy\frs\core\forms;



use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use pocketmine\player\Player;
use pocketmine\Server;

class FRSForm extends MenuForm {

    public function __construct() {

        parent::__construct("- FRS -",
            "> §gSelect a Action ",

            [
                new \dktapps\pmforms\MenuOption("> Get Online List <"),
                new \dktapps\pmforms\MenuOption("> Get Your Ping <"),
                new \dktapps\pmforms\MenuOption("> World Info <"),
                new \dktapps\pmforms\MenuOption("> Your Stats <"),

            ],

            function (Player $player, int $selectedOption): void {

                switch ($selectedOption) {

                    case 0:
                        $server = Server::getInstance();
                        $players = $server->getOnlinePlayers();

                        $playerList = "Players Online:\n";
                        foreach ($players as $onlinePlayer) {
                            $playerList .= $onlinePlayer->getName() . "\n";
                        }

                        $player->sendMessage($playerList);
                        break;

                    case 1:

                        $ping = $player->getNetworkSession()->getPing();
                        $pingMsg = "§aYour Connection:\n";
                        $pingMsg .= "§7Ping: §f" . $ping . "ms\n";

                        if ($ping < 50) {
                            $pingMsg .= "§7Status: §aExcellent";
                        } elseif ($ping < 100) {
                            $pingMsg .= "§7Status: §eGood";
                        } elseif ($ping < 200) {
                            $pingMsg .= "§7Status: §6Fair";
                        } else {
                            $pingMsg .= "§7Status: §cPoor";
                        }

                        $player->sendMessage($pingMsg);


                        break;


                    case 2:

                        $world = $player->getWorld();
                        $worldInfo = "§aWorld Information:\n";
                        $worldInfo .= "§7Name: §f" . $world->getFolderName() . "\n";
                        $worldInfo .= "§7Time: §f" . $world->getTime() . "\n";
                        $worldInfo .= "§7Players: §f" . count($world->getPlayers()) . "\n";
                        $worldInfo .= "§7Spawn: §f" . $world->getSpawnLocation()->getX() . ", " . $world->getSpawnLocation()->getY() . ", " . $world->getSpawnLocation()->getZ();

                        $player->sendMessage($worldInfo);


                        break;



                    case 3:


                        $stats = "§aYour Stats:\n";
                        $stats .= "§7Health: §f" . round($player->getHealth(), 1) . "/" . $player->getMaxHealth() . "\n";
                        $stats .= "§7Food: §f" . $player->getHungerManager()->getFood() . "/20\n";
                        $stats .= "§7XP Level: §f" . $player->getXpManager()->getXpLevel() . "\n";
                        $stats .= "§7Game Mode: §f" . $player->getGamemode()->getEnglishName();

                        $player->sendMessage($stats);


                        break;

                }
            }
        );
    }
}