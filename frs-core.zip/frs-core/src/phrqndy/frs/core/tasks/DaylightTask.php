<?php

namespace tasks;

use pocketmine\scheduler\Task;
use pocketmine\Server;

class DaylightTask extends Task
{
    public function onRun(): void
    {
        foreach (Server::getInstance()->getWorldManager()->getWorlds() as $worlds) {
            $worlds->setTime(1000);
            $worlds->stopTime();
        }
    }
}