<?php

namespace phrqndy\frs\core\listeners;


use phrqndy\frs\core\forms\FRSForm;
use phrqndy\frs\core\MANUKit;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\utils\TextFormat;

class PlayerListener implements Listener {

    public function onPlayerJoin(PlayerJoinEvent $event) {

        $player = $event->getPlayer();

        MANUKit::sendLobbyKit($player);

        $player->sendTitle("§a§kB §r§a§lFRS §a§kB");
    }

    public function onPlayerInteract(PlayerInteractEvent $event): void {

        $player = $event->getPlayer();

        $item = $event->getItem();

        switch ($item->getName()) {

            case TextFormat::GREEN . "FRS";


            $player->sendForm(new FRSForm());



            break;
        }

    }

}