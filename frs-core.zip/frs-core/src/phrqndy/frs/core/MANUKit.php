<?php

namespace phrqndy\frs\core;



use pocketmine\item\VanillaItems;
use pocketmine\player\GameMode;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;

class MANUKit
{


    public static function sendLobbyKit(Player $player)
    {
        $player->getInventory()->clearAll();
        $player->getCursorInventory()->clearAll();
        $player->getArmorInventory()->clearAll();
        $player->setGamemode(GameMode::ADVENTURE());
        $player->getHungerManager()->setFood(20);
        $player->getHungerManager()->setEnabled(false);
        $player->setMaxHealth(20);
        $player->setHealth(20);
        $player->getInventory()->setHeldItemIndex(0);
        $player->getEffects()->clear();
        $player->getInventory()->setItem("4", VanillaItems::EMERALD()->setCustomName(TextFormat::GREEN . "FRS"));


    }
}


